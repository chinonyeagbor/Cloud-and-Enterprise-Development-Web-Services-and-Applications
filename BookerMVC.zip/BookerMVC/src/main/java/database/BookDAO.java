package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Book;

/**
 * The BookDAO class provides access to a database of books.
 * It creates a connection to the database using JDBC and the MySQL driver.
 */
public class BookDAO {
	
	private Connection conn;
	
	/**
	 * Constructs a new BookDAO object.
	 */
	public BookDAO() {}
	
	/**
	 * Returns a Connection object that represents a connection to the database.
	 *
	 * @return a Connection object representing a connection to the database
	 * @throws SQLException if there is a problem connecting to the database
	 */
	private Connection getDBConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
        	try {
        	    Class.forName("com.mysql.jdbc.Driver");
        	} catch (ClassNotFoundException e) {
        	    e.printStackTrace();
        	}

        	
        	String dbURL = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/ogbonnac";
            conn = DriverManager.getConnection(dbURL, "ogbonnac", "jenkLewp6");
        }
        return conn;
    }
	
	/**
	Returns a list of books from the database.
	@param offset the offset for the first row to retrieve from the database
	@param pageSize the maximum number of rows to retrieve from the database
	@return a list of books retrieved from the database
	@throws SQLException if there is a problem executing the SQL query or retrieving data from the database
	*/
	public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books";
        try (
            Connection conn = getDBConnection();
            PreparedStatement ps = conn.prepareStatement(query)) {
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Book book = new Book();
                    book.setId(rs.getInt("id"));
                    book.setTitle(rs.getString("title"));
                    book.setAuthor(rs.getString("author"));
                    book.setDate(rs.getString("date"));
                    book.setGenres(rs.getString("genres"));
                    book.setCharacters(rs.getString("characters"));
                    book.setSynopsis(rs.getString("synopsis"));
                    books.add(book);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
            throw e;
        }
        return books;
    }
	
	/**
	Retrieves a book from the database with the given ID.
	@param id the ID of the book to retrieve
	@return the Book object corresponding to the given ID
	@throws SQLException if there is an error accessing the database
	*/
	public Book getBook(int id) throws SQLException {
	    String query = "SELECT * FROM books WHERE id = ?";
	    Book book = new Book();
	    
	    try (
	    	Connection conn = getDBConnection();
	        PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, id);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                book.setId(rs.getInt("id"));
	                book.setTitle(rs.getString("title"));
	                book.setAuthor(rs.getString("author"));
	                book.setDate(rs.getString("date"));
	                book.setGenres(rs.getString("genres"));
	                book.setCharacters(rs.getString("characters"));
	                book.setSynopsis(rs.getString("synopsis"));
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        throw e;
	    }
	    return book;
	}

	/**
	Inserts a new book into the database.
	@param book the book to be inserted
	@return true if the book was inserted successfully, false otherwise
	@throws SQLException if there is a problem inserting the book into the database
	*/
	public boolean insertBook(Book book) throws SQLException {
	    boolean bookInserted = false;
	    String query = "INSERT INTO books (title, author, date, genres, characters, synopsis) VALUES (?, ?, ?, ?, ?, ?)";
	   	    
	    try (Connection connection = getDBConnection();
	         PreparedStatement ps = connection.prepareStatement(query)) {
	        ps.setString(1, book.getTitle());
	        ps.setString(2, book.getAuthor());
	        ps.setString(3, book.getDate());
	        ps.setString(4, book.getGenres());
	        ps.setString(5, book.getCharacters());
	        ps.setString(6, book.getSynopsis());
	        
	        ps.executeUpdate();
	        bookInserted = true;
	        System.out.println("Book Inserted");
	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        throw e;
	    }
	    return bookInserted;
	}

	/**
	Updates the book with the given Book object information in the database.
	@param book a Book object representing the book to be updated in the database
	@return true if the book was updated successfully, false otherwise
	@throws SQLException if there is a problem with the SQL query or connection
	*/
	public boolean updateBook(Book book) throws SQLException {
	    boolean bookUpdated = false;
	    String query = "UPDATE books SET title=?, author=?, date=?, genres=?, characters=?, synopsis=? WHERE id=?";

	    try (Connection connection = getDBConnection();
	         PreparedStatement ps = connection.prepareStatement(query)) {
	        ps.setString(1, book.getTitle());
	        ps.setString(2, book.getAuthor());
	        ps.setString(3, book.getDate());
	        ps.setString(4, book.getGenres());
	        ps.setString(5, book.getCharacters());
	        ps.setString(6, book.getSynopsis());
	        ps.setInt(7, book.getId());

	        int rowsUpdated = ps.executeUpdate();
	        if (rowsUpdated > 0) {
	            bookUpdated = true;
	            System.out.println("Book updated successfully");
	        } else {
	            System.out.println("No book found with the given id");
	        }
	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        throw e;
	    }
	    return bookUpdated;
	}

	/**
	Deletes a book from the database.
	@param id the id of the book to delete
	@return true if the book is successfully deleted, false otherwise
	@throws SQLException if there is a problem connecting to the database or deleting the book
	*/
	public boolean deleteBook(int id) throws SQLException {
	    boolean bookDeleted = false;
	    String query = "DELETE FROM books WHERE id = ?";

	    try (Connection conn = getDBConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, id);
	        int rowsDeleted = ps.executeUpdate();
	        if (rowsDeleted > 0) {
	            bookDeleted = true;
	            System.out.println("Book with id " + id + " deleted successfully");
	        } else {
	            System.out.println("No book found with the given id");
	        }
	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        throw e;
	    }
	    return bookDeleted;
	}

	/**
	 * Retrieves a list of books that match the given title search query from the database.
	 *
	 * @param searchName the title to search for in the book titles, author or genres
	 * @return an ArrayList of Book objects that match the search query
	 * @throws SQLException if there is a problem accessing the database
	 */
	public List<Book> searchBook(String search) throws SQLException {
		String query = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genres LIKE ?";
	    List<Book> books = new ArrayList<>();

	    try (Connection conn = getDBConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setString(1, "%" + search + "%");
	        ps.setString(2, "%" + search + "%");
	        ps.setString(3, "%" + search + "%");

	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                Book book = new Book();
	                book.setId(rs.getInt("id"));
	                book.setTitle(rs.getString("title"));
	                book.setAuthor(rs.getString("author"));
	                book.setDate(rs.getString("date"));
	                book.setGenres(rs.getString("genres"));
	                book.setCharacters(rs.getString("characters"));
	                book.setSynopsis(rs.getString("synopsis"));
	                books.add(book);
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println(e.toString());
	        throw e;
	    }

	    return books;
	}
	
	/**
	Closes the database connection if it is not already closed.
	@throws SQLException if there is a problem closing the connection
	*/
	public void closeConnection() throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }
}
