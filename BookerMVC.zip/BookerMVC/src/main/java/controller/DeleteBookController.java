package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/delete")
public class DeleteBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookDAO dao = new BookDAO();
		String _id = request.getParameter("id");
		int __id = 0;
		if (_id != null) {
			__id = Integer.parseInt(_id);
		}
		try {
			if(__id != 0) {
				dao.deleteBook(__id);
				request.setAttribute("books", dao.getAllBooks());
				request.getRequestDispatcher("./pages/allbooks.jsp").forward(request, response);
			}
			dao.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    		
	}
	}
	

	