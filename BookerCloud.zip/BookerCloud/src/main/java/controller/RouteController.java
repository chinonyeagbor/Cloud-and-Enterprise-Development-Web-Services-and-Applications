package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import model.Book;


@WebServlet("/")
public class RouteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public RouteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();//ges servelet path
		BookDAO dao = new BookDAO();
		
		switch (path) {
    	case("/"):
    		request.getRequestDispatcher("./index.jsp").forward(request, response);
        	break;
    	case("/ddelete"):
    		String _id = request.getParameter("id");
			int __id = 0;
			if (_id != null) {
				__id = Integer.parseInt(_id);
			}
			try {
				if(__id != 0) {
					dao.deleteBook(__id);
					request.setAttribute("books", dao.getAllBooks());
					request.getRequestDispatcher("./pages/allbooks.jsp").forward(request, response);
				}
				dao.closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    		
        	break;
    	case("/form"):
    		String idStr = request.getParameter("id");
    		int id = 0;
    		if (idStr != null) {
    		    id = Integer.parseInt(idStr);
    		}
    		try {
    			if(id != 0) {
    				Book book = dao.getBook(id);
    				request.setAttribute("book", book);
    				request.getRequestDispatcher("./pages/form.jsp").forward(request, response);
    			}else {
    	            request.getRequestDispatcher("./pages/form.jsp").forward(request, response);
    	        }
    			dao.closeConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    		
			
        	break;
    	default:
            break;
    }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
