package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import model.Book;

/**
 * Servlet implementation class Searchbooks
 */
@WebServlet("/search")
public class SearchBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
        public SearchBookController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// retrieve the search parameter from the URL
		String query = request.getParameter("search");	
		
		try {
			BookDAO dao = new BookDAO();
			List<Book> books = new ArrayList<>();
			
			books = dao.searchBook(query);
			request.setAttribute("books", books);
			
			request.getRequestDispatcher("./pages/allbooks.jsp").forward(request, response);
			
			// Close the database connection
			dao.closeConnection();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
