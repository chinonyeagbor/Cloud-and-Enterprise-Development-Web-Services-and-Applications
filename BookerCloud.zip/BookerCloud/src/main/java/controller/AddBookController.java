package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import model.Book;

/**
 * Servlet implementation class Add
 */
@WebServlet("/add")
public class AddBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		// Get values for the book attributes from the request parameters
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String date = request.getParameter("date");
		String genres = request.getParameter("genres");
		String characters = request.getParameter("characters");
		String synopsis = request.getParameter("synopsis");
		
		// Create a new Book object with the retrieved attribute values
		Book book = new Book(title, author, date, genres, characters, synopsis);
		
		// Create a new BookDAO object to interact with the database
		BookDAO dao = new BookDAO();
		
		try {
			// Insert the new Book into the database
			dao.insertBook(book);
			
			request.setAttribute("books", dao.getAllBooks());
			
			request.getRequestDispatcher("./pages/allbooks.jsp").forward(request, response);
			
			// Close the database connection
			dao.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
