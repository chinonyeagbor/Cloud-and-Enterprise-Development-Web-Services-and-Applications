package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import model.Book;

/**
 * Servlet implementation class Allbooks
 */
@WebServlet("/allbooks")
public class AllBooksController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// retrieve the list of books and total book count from the database
		BookDAO dao = new BookDAO();
		
		List<Book> books = new ArrayList<>();	
		try {
			//Retrieve all data from the database
			books = dao.getAllBooks();	
			
			request.setAttribute("books", books);
			
		 	// forward the request to the JSP page that displays all books
			request.getRequestDispatcher("./pages/allbooks.jsp").forward(request, response);
			
			// Close the database connection
			dao.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
