import React from 'react'
import {Navbar, Header} from '../components'
import "./styles/Landing.css"

function Landing() {
  return (
    <div className='landing-page-container'>
        <Header />
    </div>
  )
}

export default Landing