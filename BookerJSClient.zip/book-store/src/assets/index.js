import HeaderBackground from "./components/bookstore-header-image.jpg"
// import { ReactComponent as Delete } from "./components/trash-solid.svg"
// import { ReactComponent as Edit } from "./components/pen-to-square-solid.svg"

export {
    HeaderBackground,
}