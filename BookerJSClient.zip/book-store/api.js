function baseURL(){
    return "http://localhost:8081/BookerRESTful/bookapi"
}

export {
    baseURL
}