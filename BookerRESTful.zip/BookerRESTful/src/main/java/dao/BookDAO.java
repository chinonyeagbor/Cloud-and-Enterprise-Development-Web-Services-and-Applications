package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import classes.Book;

/**
 * The BookDAO class provides access to a database of books.
 * It creates a connection to the database using JDBC and the MySQL driver.
 */


public class BookDAO {
	private Connection conn = null;
	
	public BookDAO() {
        try {
            this.conn = getDBConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	
	public Connection getDBConnection() throws Exception {
        if (this.conn == null || this.conn.isClosed()) {
            String jsonPath = "service-account-file.json";
            System.setProperty("GOOGLE_APPLICATION_CREDENTIALS", jsonPath);
        
            String instanceConnectionName = "course-work-387216:europe-west2:bookersql";
            String databaseName = "Books";
            String username = "root";
            String password = "password1";
            String jdbcUrl = String.format(
                    "jdbc:mysql:///%s?cloudSqlInstance=%s&socketFactory=com.google.cloud.sql.mysql.SocketFactory&user=%s&password=%s&characterEncoding=UTF-8",
                    databaseName,
                    instanceConnectionName,
                    username,
                    password);
            
            conn = DriverManager.getConnection(jdbcUrl);
            if(conn != null) {
                System.out.println("Connected");
            } else {
                System.out.println("Not Connected");
            }
        }
        return conn;
    }
	
	/**
	Returns a list of books from the database.
	@param offset the offset for the first row to retrieve from the database
	@param pageSize the maximum number of rows to retrieve from the database
	@return a list of books retrieved from the database
	@throws SQLException if there is a problem executing the SQL query or retrieving data from the database
	*/
	public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM books";
        try (
            Connection conn = getDBConnection();
            PreparedStatement ps = conn.prepareStatement(query)) {
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Book book = new Book();
                    book.setId(rs.getInt("id"));
                    book.setTitle(rs.getString("title"));
                    book.setAuthor(rs.getString("author"));
                    book.setDate(rs.getString("date"));
                    book.setGenres(rs.getString("genres"));
                    book.setCharacters(rs.getString("characters"));
                    book.setSynopsis(rs.getString("synopsis"));
                    books.add(book);
                }
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return books;
    }
	
	/**
	Retrieves a book from the database with the given ID.
	@param id the ID of the book to retrieve
	@return the Book object corresponding to the given ID
	@throws SQLException if there is an error accessing the database
	*/
	public Book getBook(int id) throws SQLException {
	    String query = "SELECT * FROM books WHERE id = ?";
	    Book book = new Book();
	    
	    try (
	    	Connection conn = getDBConnection();
	        PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, id);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                book.setId(rs.getInt("id"));
	                book.setTitle(rs.getString("title"));
	                book.setAuthor(rs.getString("author"));
	                book.setDate(rs.getString("date"));
	                book.setGenres(rs.getString("genres"));
	                book.setCharacters(rs.getString("characters"));
	                book.setSynopsis(rs.getString("synopsis"));
	            }
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	      
	    }
	    return book;
	}

	/**
	Inserts a new book into the database.
	@param book the book to be inserted
	@return int if the book was inserted successfully.
	@throws SQLException if there is a problem inserting the book into the database
	*/
	public int insertBook(Book book) throws SQLException {
	    String query = "INSERT INTO books (title, author, date, genres, characters, synopsis) VALUES (?, ?, ?, ?, ?, ?)";

	    ResultSet generatedKeys = null;
	    try (Connection connection = getDBConnection();
	         PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

	        ps.setString(1, book.getTitle());
	        ps.setString(2, book.getAuthor());
	        ps.setString(3, book.getDate());
	        ps.setString(4, book.getGenres());
	        ps.setString(5, book.getCharacters());
	        ps.setString(6, book.getSynopsis());

	        int affectedRows = ps.executeUpdate();

	        if (affectedRows == 0) {
	            throw new SQLException("Creating book failed, no rows affected.");
	        }

	        generatedKeys = ps.getGeneratedKeys();
	        if (generatedKeys.next()) {
	            return generatedKeys.getInt(1);
	        } 

	    } catch (Exception e) {
	        System.out.println(e.toString());
	   
   } finally {
	        if (generatedKeys != null) {
	            try {
	                generatedKeys.close();
	            } catch (SQLException e) {
	                System.out.println(e.toString());
	            }
	        }
	    }
	    
	    return generatedKeys.getInt(1);
	}


	/**
	Updates the book with the given Book object information in the database.
	@param book a Book object representing the book to be updated in the database
	@return true if the book was updated successfully, false otherwise
	@throws SQLException if there is a problem with the SQL query or connection
	*/
	public boolean updateBook(Book book) throws SQLException {
	    boolean bookUpdated = false;
	    String query = "UPDATE books SET title=?, author=?, date=?, genres=?, characters=?, synopsis=? WHERE id=?";

	    try (Connection connection = getDBConnection();
	         PreparedStatement ps = connection.prepareStatement(query)) {
	        ps.setString(1, book.getTitle());
	        ps.setString(2, book.getAuthor());
	        ps.setString(3, book.getDate());
	        ps.setString(4, book.getGenres());
	        ps.setString(5, book.getCharacters());
	        ps.setString(6, book.getSynopsis());
	        ps.setInt(7, book.getId());

	        int rowsUpdated = ps.executeUpdate();
	        if (rowsUpdated > 0) {
	            bookUpdated = true;
	            System.out.println("Book updated successfully");
	        } else {
	            System.out.println("No book found with the given id");
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	       
	    }
	    return bookUpdated;
	}

	/**
	Deletes a book from the database.
	@param id the id of the book to delete
	@return true if the book is successfully deleted, false otherwise
	@throws SQLException if there is a problem connecting to the database or deleting the book
	*/
	public boolean deleteBook(int id) throws SQLException {
	    boolean bookDeleted = false;
	    String query = "DELETE FROM books WHERE id = ?";

	    try (Connection conn = getDBConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setInt(1, id);
	        int rowsDeleted = ps.executeUpdate();
	        if (rowsDeleted > 0) {
	            bookDeleted = true;
	            System.out.println("Book with id " + id + " deleted successfully");
	        } else {
	            System.out.println("No book found with the given id");
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	        
	    }
	    return bookDeleted;
	}

	/**
	 * Retrieves a list of books that match the given title search query from the database.
	 *
	 * @param searchName the title to search for in the book titles, author or genres
	 * @return an ArrayList of Book objects that match the search query
	 * @throws SQLException if there is a problem accessing the database
	 */
	public List<Book> searchBook(String search) throws SQLException {
		String query = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genres LIKE ?";
	    List<Book> books = new ArrayList<>();

	    try (Connection conn = getDBConnection();
	         PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setString(1, "%" + search + "%");
	        ps.setString(2, "%" + search + "%");
	        ps.setString(3, "%" + search + "%");

	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                Book book = new Book();
	                book.setId(rs.getInt("id"));
	                book.setTitle(rs.getString("title"));
	                book.setAuthor(rs.getString("author"));
	                book.setDate(rs.getString("date"));
	                book.setGenres(rs.getString("genres"));
	                book.setCharacters(rs.getString("characters"));
	                book.setSynopsis(rs.getString("synopsis"));
	                books.add(book);
	            }
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	    }	       


	    return books;
	}

	/**
	 * Returns the total number of books in the database.
	 *
	 * @return the total number of books
	 * @throws SQLException if an error occurs while retrieving the total number of books
	 */
	public int getTotalBooks() throws SQLException {
	    int totalBooks = 0;
	    String query = "SELECT count(*) FROM books";

	    try (Connection conn = getDBConnection();
	         PreparedStatement ps = conn.prepareStatement(query);
	         ResultSet rs = ps.executeQuery()) {
	        if (rs.next()) {
	            totalBooks = rs.getInt(1);
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	        
	    }

	    return totalBooks;
	}

	/**
	 * Get the total number of books in the search result based on the given search query.
	 * 
	 * @param search The search query to look for in the book titles, author or genres.
	 * @return The total number of books in the search result.
	 * @throws SQLException If there is an error executing the SQL query.
	 */
	public int getTotalSearchBooks(String search) throws SQLException {
	    String query = "SELECT COUNT(*) FROM books WHERE title LIKE ? OR author LIKE ? OR genres LIKE ?";
	    int totalBooks = 0;

	    try (Connection conn = getDBConnection();
      PreparedStatement ps = conn.prepareStatement(query)) {
	        ps.setString(1, "%" + search + "%");
	        ps.setString(2, "%" + search + "%");
	        ps.setString(3, "%" + search + "%");

	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                totalBooks = rs.getInt(1);
	            }
	        }
	    } catch (Exception e) {
	        System.out.println(e.toString());
	     
	    }

	    return totalBooks;
	}
	
	/**
	Closes the database connection if it is not already closed.
	@throws SQLException if there is a problem closing the connection
	*/
	public void closeConnection() throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }

	/**

	Calculates the total number of pages given the total count of items and the page size.
	@param totalCount the total number of items.
	@param pageSize the number of items per page.
	@return an array of integers representing the page numbers.
	*/
	public int[] getPages(int totalCount, int pageSize) {
	    int numPages = (int) Math.ceil((double) totalCount / pageSize);
	    int[] pages = new int[numPages];
	    for (int i = 0; i < numPages; i++) {
	        pages[i] = i + 1;
	    }
	    return pages;
	}

}
