package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import classes.Book;
import classes.BookResultWrapper;
import classes.SuccessMessage;
import dao.BookDAO;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

/**
 * Servlet implementation class Api
 */

public class Api extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Api() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    //To Get all books
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	//Creates a Gson instance for JSON serialization
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        
        //creates a BookDAO instance to interact with the database
        BookDAO dao = new BookDAO();
        
        //Retrieve query parameters from the request
        String title = request.getParameter("query");
        String format = request.getParameter("format");
        String id = request.getParameter("id");
        
        try {
            if (id != null) {
            	//Retrieves a single book by id from the database 
                int bookId = Integer.parseInt(id);
                Book book = dao.getBook(bookId);

                if ("xml".equalsIgnoreCase(format)) {
                    respondWithXmlSingle(response, book);
                } else if ("text".equalsIgnoreCase(format)) {
                    respondWithRawText(response, book.toString());
                } else {
                    respondWithJson(response, gson.toJson(book));
                } 
            } else {
                List<Book> books = (title != null)
                        ? dao.searchBook(title)
                        : dao.getAllBooks();
                
                if (!books.isEmpty()) {
                    if ("xml".equalsIgnoreCase(format)) {
                        respondWithXml(response, books);
                    } else if ("text".equalsIgnoreCase(format)) {
                        StringBuilder sb = new StringBuilder();
                        for (Book book : books) {
                            sb.append(book.toString()).append("\n");
                        }
                        respondWithRawText(response, sb.toString());
                    } else {
                        respondWithJson(response, gson.toJson(books));
                    }
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    respondWithRawText(response, "No books found");
                }
            }
        } catch (SQLException | JAXBException e) {
            throw new ServletException("Error processing request", e);
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
    //To insert a new book in the database
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	//Creates a Gson instance for JSON serialization
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        //creates a BookDAO instance to interact with the database
        BookDAO dao = new BookDAO();
        //Retrieves the format parameter from the request
        String format = request.getParameter("format");

        try {
        	//Read the request body and deserializes it into a book object
            String requestBody = readRequestBody(request);
            Book newBook = gson.fromJson(requestBody, Book.class);
            
            //Inserts the new book into the database
            int id = dao.insertBook(newBook);
            System.out.println(id + "id");

            if ("xml".equalsIgnoreCase(format)) {
            	respondWithXmlSingle(response, dao.getBook(id));
            } else if ("text".equalsIgnoreCase(format)) {
                respondWithRawText(response, dao.getBook(id).toString());
            } else {
                respondWithJson(response, gson.toJson(dao.getBook(id)));
            }
        } catch (SQLException | JAXBException e) {
            throw new ServletException("Error processing request", e);
        }
    }

	//To update a Book
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	//Create a Gson instance for JSON serialization
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        //creates a BookDAO instance to interact with the database
        BookDAO dao = new BookDAO();
        //Retrieves the format parameter from the request
        String format = request.getParameter("format");

        try {
        	//Read the request body and deserialize it into a Book object
            String requestBody = readRequestBody(request);
            Book updatedBook = gson.fromJson(requestBody, Book.class);
            //update the book in the database
            dao.updateBook(updatedBook);

            if ("xml".equalsIgnoreCase(format)) {
            	respondWithXmlSingle(response, updatedBook);
            } else if ("text".equalsIgnoreCase(format)) {
                respondWithRawText(response, updatedBook.toString());
            } else {
                respondWithJson(response, gson.toJson(updatedBook));
            }
        } catch (SQLException | JAXBException e) {
            throw new ServletException("Error processing request", e);
        }
    }
    //To delete a book
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	//Creates a Gson instance for JSON serialization
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        //creates a BookDAO instance to interact with the database
        BookDAO dao = new BookDAO();
        int id = Integer.parseInt(request.getParameter("id"));
        String format = request.getParameter("format");        

        try {
            dao.deleteBook(id);
            //creates a success message
            SuccessMessage successMessage = new SuccessMessage(true);

            if ("xml".equalsIgnoreCase(format)) {
            	respondWithXmlSingle(response, successMessage);
            } else if ("text".equalsIgnoreCase(format)) {
                respondWithRawText(response, "success: true");
            } else {
                respondWithJson(response, gson.toJson(Collections.singletonMap("success", true)));
            }
        } catch (SQLException | JAXBException e) {
            throw new ServletException("Error processing request", e);
        }
    }

    /**
     * Reads the request body as a string.
     *
     * @param request The HttpServletRequest object representing the request.
     * @return The request body as a string.
     * @throws IOException If an I/O error occurs while reading the request body.
     */
    
    private String readRequestBody(HttpServletRequest request) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;

        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        return sb.toString();
    }
    
    /**
     * Sends a JSON response to the HttpServletResponse object.
     *
     * @param response The HttpServletResponse object representing the response.
     * @param json The JSON string to be sent as the response.
     * @throws IOException If an I/O error occurs while sending the response.
     */

    private void respondWithJson(HttpServletResponse response, String json) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(json);
        out.close();
    }
    
    /**
     * Sends an XML response with a single object to the HttpServletResponse object.
     *
     * @param response The HttpServletResponse object representing the response.
     * @param object The object to be sent as the response.
     * @throws IOException If an I/O error occurs while sending the response.
     * @throws JAXBException If an error occurs during JAXB marshalling.
     */
    private void respondWithXmlSingle(HttpServletResponse response, Object object) throws IOException, JAXBException {
        response.setContentType("application/xml");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JAXBContext jaxbContext = JAXBContext.newInstance(object.getClass());
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);     
        
        StringWriter writer = new StringWriter();
        marshaller.marshal(object, writer);
        out.print(writer.toString());
        out.close();
    }
    
    /**
     * Sends an XML response with a list of books to the HttpServletResponse object.
     *
     * @param response The HttpServletResponse object representing the response.
     * @param books The list of books to be sent as the response.
     * @throws IOException If an I/O error occurs while sending the response.
     * @throws JAXBException If an error occurs during JAXB marshalling.
     */
    private void respondWithXml(HttpServletResponse response, List<Book> books) throws IOException, JAXBException {
    	response.setContentType("application/xml");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        BookResultWrapper wrapper = new BookResultWrapper(books);
        JAXBContext jaxbContext = JAXBContext.newInstance(BookResultWrapper.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        marshaller.marshal(wrapper, out);
        out.close();
    }
    
    /**
     * Sends a plain text response to the HttpServletResponse object.
     *
     * @param response The HttpServletResponse object representing the response.
     * @param text The text to be sent as the response.
     * @throws IOException If an I/O error occurs while sending the response.
     */

    private void respondWithRawText(HttpServletResponse response, String text) throws IOException {
        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(text);
        out.close();
    }

}
