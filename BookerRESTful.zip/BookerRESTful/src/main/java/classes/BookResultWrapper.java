package classes;

import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "BookResult")
public class BookResultWrapper {
	//Declares a private List field to hold a collection of Book objects
    private List<Book> books;

    //Default constructor
    public BookResultWrapper() {
    }

    //constructor to take the List<Book> parameter
    public BookResultWrapper(List<Book> books) {
        this.books = books;
    }

  //Indicates that this method represents an XML element named  Book
    @XmlElement(name = "Book")
    public List<Book> getBooks() {
        return books;
    }

    //sets value of the book field
    public void setBooks(List<Book> books) {
        this.books = books;
    }    
}

