package classes;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

//provides a structure for success messages in an XML format
@XmlRootElement(name = "SuccessMessage")
public class SuccessMessage {
	private boolean success;

	//Default Constructor
    public SuccessMessage() {}
    
    //Constructor with a boolean parameter
    public SuccessMessage(boolean success) {
        this.success = success;
    }

    //indicates that this method represents an XML element named  success
    @XmlElement(name = "success")
    public boolean getSuccessMessage() {
        return success;
    }

    //Set Value of the success field
    public void setSuccessMessage(boolean success) {
        this.success = success;
    }
}
